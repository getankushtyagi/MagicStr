<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Meeting; 


class MeetingController extends Controller
{
    public function storeMeeting(Request $request){
      
        $customer = []; 
        $name[] = $request->customer_name ; 

    

        foreach($name as $nam){
          $customer[] = $nam ; 
        }

        $data = new Meeting; 
        $data->name = $request->name; 
        $data->meeting_id = $request->meeting_id ; 
        $data->passcode = $request->passcode; 
        $data->sdk_key = $request->sdk_key; 
        $data->sdk_secret = $request->sdk_secret; 
        $data->show = $request->show; 
        $data->customer_name = implode(',',$customer);
        $data->save(); 

        if($data){

            return response()->json([
                'status' => 'success',
                'data' => $data,
                'message'=>'New Meeting Created Successfully'
            ]);
        }
    }

    public function deleteMeeting($id){

        $delete = Meeting::where('id',$id)->delete(); 
        if($delete){
            return response()->json([
                'status' => 'success',
                'message'=>'Meeting Deleted Successfully'
            ]);
        }
    }

    public function bulkDeleteMeeting(Request $request){

        $id[]  = $request->id ; 

        foreach($id as $i){

            Meeting::where('id',$i)->delete(); 

        }
        return response()->json([
            'status' => 'success',
            'message'=>'Meeting Deleted Successfully'
        ]);

    }
}
