<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AuthController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login','register']]);
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
        ]);
        $credentials = $request->only('email', 'password');


        $token = Auth::attempt($credentials);
        if (!$token) {
            return response()->json([
                'status' => 'error',
                'message' => 'Unauthorized',
            ], 401);
        }
        $user = Auth::user();
        if($user->login_status=='1'){
            return response()->json([
                'status' => 'error',
                'message' => 'Already Login',
            ], 401);
            
        }else {
           $update = User::where('appId',$user->appId)->update([
                 'login_status'=>'1'
           ]); 

            return response()->json([
                'status' => 'success',
                'user' => $user,
                'authorisation' => [
                    'token' => $token,
                    'type' => 'bearer',
                ]
            ]);

        }
       
    }

    public function register(Request $request){
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6',
            'role_id'=>'required'
        ]);

        $user = new User; 
        $user->appId = 'app_'.uniqid(); 
        $user->name = $request->name; 
        $user->email = $request->email; 
        $user->password = Hash::make($request->password);
        $user->login_status = '0'; 
        $user->role_id = $request->role_id; 
        $user->save(); 

        $token = Auth::login($user);

        return response()->json([
            'status' => 'success',
            'message' => 'User created successfully',
            'user' => $user,
            'authorisation' => [
                'token' => $token,
                'type' => 'bearer',
            ]
        ]);
    }

    public function logout(Request $request)
    {    
      $user_appId = $request->user_appId;   

      $status = User::where('appId',$user_appId)->get();

        

        if(count($status) > 0){

            $update = User::where('appId',$user_appId)->update([
                'login_status'=>'0'
            ]);
        }
        Auth::logout();
        return response()->json([
            'status' => 'success',
            'message' => 'Successfully logged out',
        ]);
    }

    public function refresh()
    {
        return response()->json([
            'status' => 'success',
            'user' => Auth::user(),
            'authorisation' => [
                'token' => Auth::refresh(),
                'type' => 'bearer',
            ]
        ]);
    }
}
// app_639deda825c7e