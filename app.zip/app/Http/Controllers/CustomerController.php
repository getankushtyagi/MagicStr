<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer; 

class CustomerController extends Controller
{
    public function storeCustomer(){

        $data = new Customer; 
        $data->name = $request->name; 
        $data->username = $request->username; 
        $data->password = $request->password; 
        $data->points = $request->points; 
        $data->active_date = $request->active_date; 
        $data->plan_expiry_date = $request->plan_expiry_date; 
        $data->save(); 
        if($data){
            return response()->json([
                'status' => 'success',
                'data' => $data,
                'message'=>'New Customer Created Successfully'
            ]);
        }


    }
}
